public class Weapon_24129429 {

    private Position_24129429 pos;
    private final double offense;

    public Weapon_24129429(Position_24129429 pos, double offense) {
        this.pos = pos;
        this.offense = offense;
    }

    public Position_24129429 getPosition() {
        return pos;
    }

    public double getOffense() {
        return offense;
    }

    public void setPosition(Position_24129429 pos){
        this.pos = pos;
    }
}
