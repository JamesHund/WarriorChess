Main class is located within Game_24129429.
Run project using plain visual output.
